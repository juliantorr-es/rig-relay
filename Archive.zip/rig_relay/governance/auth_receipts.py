# ruff: noqa: PLR0911
"""Rig Relay Authorization Receipts — Governance Seam.

Owned by ``rig_relay.governance``. Legacy adapter at ``vibe.core.auth.receipt``.

Usage:
    from rig_relay.governance.auth_receipts import validate_receipt, generate_dev_receipt
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
import hashlib
import json
import secrets
from typing import Any


@dataclass
class AuthorizationResult:
    authorized: bool
    receipt: dict[str, Any] | None = None
    reason: str | None = None


DEFAULT_POLICY: dict[str, Any] = {
    "schema_version": "rig.relay.authorization_policy.v1",
    "protected_actions": [
        "remote_upload.confirm",
        "telemetry.share_level.change",
        "checkpoint.commit",
        "spawn.execute",
        "fleet.execute",
        "lease_cleanup.archive",
        "lease_cleanup.remove",
        "credentials.configure",
        "update.restart_now",
    ],
    "action_methods": {
        "remote_upload.confirm": [
            "none_dev_only",
            "local_system_auth",
            "passkey_webauthn",
        ],
        "telemetry.share_level.change": ["none_dev_only", "local_system_auth"],
        "checkpoint.commit": ["none_dev_only", "local_system_auth"],
        "spawn.execute": ["none_dev_only", "local_system_auth"],
        "fleet.execute": ["none_dev_only", "local_system_auth"],
        "lease_cleanup.archive": ["none_dev_only", "local_system_auth"],
        "lease_cleanup.remove": ["none_dev_only", "local_system_auth"],
        "credentials.configure": ["none_dev_only", "local_system_auth"],
        "update.restart_now": ["none_dev_only", "local_system_auth"],
    },
    "receipt_ttl_seconds": 300,
    "default_method": "local_system_auth",
    "allow_dev_bypass": True,
    "warnings": [],
}

READ_ONLY_ACTIONS = frozenset({
    "current_state.view",
    "dataset_report.read",
    "cockpit.read",
    "dry_run.upload",
    "dry_run.spawn_plan",
    "dry_run.lease_cleanup",
    "schema.validate",
    "search.read",
})


def _sha256_bytes(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _generate_id() -> str:
    return "authz_" + secrets.token_hex(16)


def action_requires_authorization(
    action: str, policy: dict[str, Any] | None = None
) -> bool:
    """Check whether an action requires step-up authorization."""
    if policy is None:
        policy = DEFAULT_POLICY
    return action in policy.get("protected_actions", [])


def is_read_only_action(action: str) -> bool:
    """Check whether an action is read-only and does not require step-up."""
    return action in READ_ONLY_ACTIONS


def validate_receipt(
    receipt: dict[str, Any],
    action: str,
    action_scope: dict[str, Any] | None = None,
    policy: dict[str, Any] | None = None,
) -> tuple[bool, str]:
    """Validate an authorization receipt against an action and optional scope.

    Args:
        receipt: Authorization receipt dict.
        action: Action to validate against.
        action_scope: Optional scope dict with target_sha256.
        policy: Authorization policy dict. Uses defaults if None.

    Returns:
        Tuple of (valid: bool, reason: str).
    """
    if policy is None:
        policy = DEFAULT_POLICY

    if receipt.get("schema_version") != "rig.relay.step_up_authorization_receipt.v1":
        return False, "Invalid schema version"

    receipt_action = receipt.get("action")
    if receipt_action != action:
        return (
            False,
            f"Action mismatch: receipt for '{receipt_action}', expected '{action}'",
        )

    if receipt.get("user_verified") is not True:
        return False, "User not verified"

    expires_at_str = receipt.get("expires_at", "")
    if not expires_at_str:
        return False, "Missing expires_at"

    try:
        expires_dt = datetime.fromisoformat(expires_at_str.replace("Z", "+00:00"))
        if expires_dt < datetime.now(UTC):
            return False, "Receipt expired"
    except (ValueError, TypeError):
        return False, "Invalid expires_at format"

    if action_scope and action_scope.get("target_sha256"):
        receipt_scope = receipt.get("action_scope") or {}
        if receipt_scope.get("target_sha256") != action_scope["target_sha256"]:
            return False, "Action scope target_sha256 mismatch"

    method = receipt.get("method", "")
    allowed = policy.get("action_methods", {}).get(
        action, [policy.get("default_method", "local_system_auth")]
    )

    if method not in allowed:
        return False, f"Method '{method}' not allowed for action '{action}'"

    return True, "Receipt valid"


def generate_dev_receipt(
    action: str, action_scope: dict[str, Any] | None = None, ttl_seconds: int = 300
) -> dict[str, Any]:
    """Generate a developer/test authorization receipt (none_dev_only method).

    Args:
        action: Action to authorize.
        action_scope: Optional scope dict.
        ttl_seconds: Receipt TTL in seconds.

    Returns:
        Authorization receipt dict.
    """
    now = datetime.now(UTC)
    expires = now + timedelta(seconds=ttl_seconds)
    authz_id = _generate_id()
    challenge = secrets.token_bytes(32)
    challenge_hash = _sha256_bytes(challenge)

    receipt = {
        "schema_version": "rig.relay.step_up_authorization_receipt.v1",
        "authorization_id": authz_id,
        "created_at": now.isoformat(),
        "action": action,
        "action_scope": action_scope or {},
        "method": "none_dev_only",
        "user_verified": True,
        "expires_at": expires.isoformat(),
        "challenge_sha256": challenge_hash,
        "credential_id_hash": None,
        "receipt_sha256": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
        "warnings": ["Dev receipt — no real user verification performed"],
    }

    receipt_data = json.dumps(receipt, sort_keys=True).encode("utf-8")
    receipt["receipt_sha256"] = _sha256_bytes(receipt_data)
    return receipt


def resolve_authorization(
    action: str,
    receipt_json: str | None = None,
    action_scope: dict[str, Any] | None = None,
    policy: dict[str, Any] | None = None,
    checkpoint_dev_bypass_enabled: bool = False,
) -> AuthorizationResult:
    if policy is None:
        policy = DEFAULT_POLICY

    if receipt_json:
        try:
            receipt = json.loads(receipt_json)
        except json.JSONDecodeError:
            return AuthorizationResult(authorized=False, reason="Invalid receipt JSON")
        valid, reason = validate_receipt(receipt, action, action_scope, policy)
        if not valid:
            return AuthorizationResult(authorized=False, reason=reason)
        return AuthorizationResult(authorized=True, receipt=receipt)

    if not checkpoint_dev_bypass_enabled:
        return AuthorizationResult(authorized=False, reason="dev_bypass_disabled")

    dev_receipt = generate_dev_receipt(
        action, action_scope, policy.get("receipt_ttl_seconds", 300)
    )
    return AuthorizationResult(authorized=True, receipt=dev_receipt)


def mint_dev_receipt(
    action: str,
    action_scope: dict[str, Any] | None = None,
    ttl_seconds: int = 300,
    checkpoint_dev_bypass_enabled: bool = False,
) -> dict[str, Any] | None:
    if not checkpoint_dev_bypass_enabled:
        return None
    return generate_dev_receipt(action, action_scope, ttl_seconds)


__all__ = [
    "DEFAULT_POLICY",
    "READ_ONLY_ACTIONS",
    "AuthorizationResult",
    "action_requires_authorization",
    "generate_dev_receipt",
    "is_read_only_action",
    "mint_dev_receipt",
    "resolve_authorization",
    "validate_receipt",
]
