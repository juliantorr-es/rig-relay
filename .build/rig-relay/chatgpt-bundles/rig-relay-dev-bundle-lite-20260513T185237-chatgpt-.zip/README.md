# Rig Relay Dev Bundle — lite profile

**Bundle ID:** chatgpt-dev-c328a41df21e
**Generated:** 2026-05-13T18:52:37.828834+00:00
**Profile:** lite
**Target size:** 100 MB

## What this is

This is a curated, token-budgeted, content-light analysis bundle of Rig Relay
structured data. It is designed for upload to ChatGPT for analysis.

Lightweight overview with key metrics, dataset counts, schema index, and executive summary. Under 25 MB.

## What to inspect first

1. **`executive-summary.json`** — Key metrics and state overview
2. **`dataset-counts.json`** — Row counts and derived dataset summaries
3. **`manifest.json`** — Full manifest with token estimates, included files, and warnings
4. **`current-state.json`** — Current coordination state snapshot
5. **`source-map.json`** — Map of available artifacts and their status

## What is intentionally excluded

- **Raw prompts**: No user or assistant prompts
- **Raw model outputs**: No model-generated text
- **Raw source code**: No source code files
- **stdout/stderr bodies**: No command output
- **Diffs and patches**: No file diffs or patch files
- **Secrets and keys**: No API keys, tokens, or private keys
- **Raw observability logs**: No raw `observability.jsonl` files
- **Full coordination event stream**: Only sampled/capped derived rows
- **Schema files**: Only schema index (schema JSON files excluded)
- **Governance docs**: Excluded to keep bundle focused (reference the repo)

## Content-light guarantee

This bundle contains NO raw prompts, NO raw model outputs, NO source code,
NO stdout/stderr bodies, NO diffs, and NO secrets. All data is content-light:
counts, hashes, statuses, schema IDs, event names, and structured summaries.

## File structure

```
chatgpt-bundle/
  README.md              — This file
  manifest.json          — Full manifest with token estimates and warnings
  executive-summary.json — Key metrics and state at a glance
  dataset-counts.json    — Row counts and derived dataset summaries
  current-state.json     — Current coordination state snapshot
  schema-index.md        — Reference of all available schemas
  source-map.json        — Map of artifacts and their status
  latest-findings.jsonl  — (profile+) Latest findings rows
  latest-coordination-rows.jsonl  — (profile+) Latest coordination rows
  latest-semantic-change-snippets.jsonl  — (profile+) Latest snippets
  latest-tool-failure-rows.jsonl  — (profile+) Latest tool failure rows
```

## See also

- [Rig Relay repository](https://github.com/juliantorr-es/rig-relay)
- [docs/governance/usage-data-doctrine.md](https://github.com/juliantorr-es/rig-relay/blob/main/docs/governance/usage-data-doctrine.md)
