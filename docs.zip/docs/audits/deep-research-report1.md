# Agent Harness Determinism: Industry Trends and Rig Relay’s Strategy

## Executive Summary

Modern AI agent frameworks are increasingly engineered for **deterministic execution and efficient context reuse**. Providers and frameworks (OpenAI, Anthropic, Google, Microsoft) emphasize *prefix stability*, *prompt/KV-caching*, and *reproducible tooling*. For example, best practices include **fixing system prompts and tool definitions at the start of each conversation** so that only dynamic content (user queries, tool results) appears later【58†L101-L110】【56†L348-L358】. This enables GPU KV caches and middleware caches to hit on repeated static prefixes, dramatically cutting token costs and latency【11†L148-L157】【37†L79-L87】. 

Rig Relay’s focus on **prefix-stable context layouts and exact hashing** aligns well with these trends. Its sorting of blocks (system prompt → schema → dynamic messages) and SHA256 fingerprinting for prefix drift match recommended patterns【3†L128-L135】【58†L101-L110】. However, industry advances point to additional layers of caching and robustness. Multi-tier caches (in-memory, disk, distributed) and delta-encoding of updates are now common in high-performance agents【37†L99-L107】【56†L375-L383】. Security-conscious designs also sanitize or avoid persistent secrets in cached state【48†L905-L914】【38†L108-L117】. 

**Key tradeoffs**: Deterministic caching boosts consistency, cost, and throughput (as Amazon and OpenAI docs report【37†L79-L87】【48†L905-L914】), but adds complexity in engineering (multi-layer stores, replay logs) and risks around privacy (cached content not leaked). In practice, teams are building **audit trails**, idempotent tool interfaces, and “evidence manifests” to ensure replayability【52†L324-L332】【49†L155-L164】. In summary, Rig Relay’s current strategy (stable prefixes, exact hashes, engineering metrics) is on the right track, but it should extend to multi-tier caching, delta writes, and privacy hardening to remain future-proof.

## Industry Practices and Case Studies

### Prefix Stability and Prompt Caching

- **Stable System Prefixes:** A common rule is to **keep system prompts and tool definitions fixed at the prompt start**. Changing any token in the prefix invalidates cached K/V state【58†L101-L110】【56†L348-L358】. For example, NVIDIA’s *Dynamo* found that removing unstable headers (timestamps, billing strings) from Anthropic prompts gave a **5× speedup** by restoring GPU KV reuse【11†L148-L157】. Manus and Prompt-Engineering guides likewise warn that even a single differing token (like a timestamp) will “kill your cache hit rate”【27†L102-L110】【58†L101-L110】. In practice, developers should append variable metadata (time, request IDs) **after** the stable prefix or pass it as external metadata【58†L101-L110】.

- **Prompt Caching (API-level):** All major LLM services now support prompt-prefix caching. Amazon Bedrock and OpenAI allow **prompt-caching modes** that skip recomputation if the prefix matches a cached entry【37†L99-L107】【47†L1-L9】. In OpenAI’s doc: “Cache hits are only possible for exact prefix matches… place static content (instructions, examples) at the beginning”【47†L1-L9】. When caching hits, the model recomputes its final output but under the hood it reuses the cached hidden state; the effect is that *identical inputs yield identical outputs*【48†L905-L914】. These features drastically cut cost/latency for long, repeated prompts【37†L99-L107】. (AWS reports up to 90% token-cost savings from prompt caching【37†L99-L107】.) 

- **Explicit vs. Implicit Caching:** Google’s Gemini (and others) differentiate “implicit caching” (built into the model after a token threshold) and “explicit caching” (developer-managed). The advice is generally the same: design prompts so that *long-lived static content* (system messages, few-shot examples, long context docs) forms a reusable prefix【50†L65-L73】【58†L101-L110】, while dynamic user turns are appended. Standard frameworks (LangChain, AutoGen, Pinecone) support storing and reusing context snippets or embeddings【50†L93-L100】【38†L139-L147】.

### Deterministic Execution and Reproducibility

- **Caching Libraries:** Agent frameworks provide caches and seeds.  Microsoft’s AutoGen (and its successor Agent Framework) has a built-in **LLM cache** (disk, Redis, Cosmos) so repeated requests yield identical outputs with no API call【40†L90-L99】. It even exposes a `cache_seed` parameter: when set (default=41), AutoGen guarantees *exactly the same output for same input* by serving from its cache, unlike OpenAI’s built-in `seed` which is only “best effort”【40†L153-L161】. LangChain similarly offers an in-memory request cache for rapid local reuse during development【37†L154-L160】.

- **Structured/Idempotent Tools:** Enforcing *idempotent tool interfaces* is another strategy. By returning results as typed artifacts or references, tools become replayable. For example, Anthropic’s guidelines favor **typed, artifact-backed tool results** so that subsequent restarts can fetch from artifact stores instead of re-running heavy tool calls【56†L375-L383】. Semantic Kernel, which is built on Pydantic for state, emphasizes **deterministic tool execution**: its design “ensures that outcomes are predictable and reliable”【43†L129-L138】【43†L139-L148】.

- **Checkpoints and Audit Logs:** Robust harnesses log every decision. The *Modern Agent Blueprint* (LangGraph/Kimi style) recommends **checkpointing around all side effects** and storing a typed state + event log for replay【52†L324-L332】. This “evidence manifest” ensures if a run is resumed or audited, it can be deterministically reproduced. In practice, some teams checksum each turn’s context (like Rig Relay’s SHA256 fingerprint) and record “prefix_stability” flags for audit.

### Privacy and Security in Caching

- **Privacy by Design:** While caches boost efficiency, they must respect data boundaries. OpenAI’s docs note that prompt caches are *per-organization and ephemeral*: cached tensors live in GPU memory for minutes to hours and are not shared across organizations【48†L928-L936】. Extrapolating, any persistent cache should avoid absolute paths or raw user data to prevent leaks. The *Modern Blueprint* explicitly warns: **do not persist raw user content or absolute file paths** without redaction (Rig Relay’s audit similarly flagged this gap)【56†L469-L478】. In short, secure context caching means filtering or hashing any PII before storage, and adhering to zero-data-retention policies if required【48†L928-L936】【38†L108-L117】.

- **Authentication and Integrity:** Some high-security systems even sign or encrypt cached state. While we didn’t find a public case study explicitly on this, analogies exist: blockchain-inspired “evidence manifests” (triple-entry receipts) have been proposed for autonomous workflows to guarantee tamper-evident logs【77†L8-L13】. At a minimum, Rig Relay should implement integrity checks on its `.rig/relay` storage (e.g. through checksums or manifests) so any mid-session corruption or eviction is detected【52†L324-L332】.

### Case Study Table: Determinism Techniques

| System / Framework        | Techniques Used                                                    | Tradeoffs & Notes                                                  | Sources                     |
|---------------------------|--------------------------------------------------------------------|--------------------------------------------------------------------|-----------------------------|
| **NVIDIA Dynamo**         | Stable prefixes (stripped Anthropic preamble), server-side cache   | +5× latency speedup; requires careful prompt design                 | 【11†L148-L157】             |
| **OpenAI Prompt Cache**   | Exact-match prefix hashing, prompt_cache_key routing               | Identical inputs→identical outputs; limited to static prefixes, short retention【47†L1-L9】【48†L905-L914】 | 【47†L1-L9】【48†L905-L914】  |
| **Anthropic Claude (Harness)** | Tools at front, static system prompt; append-only chat memory; server-managed compaction | Tools reloaded breaks cache【56†L348-L358】; recommends file-backed artifacts for logs【56†L469-L478】 | 【56†L348-L358】【56†L469-L478】 |
| **Amazon Bedrock LLMs**   | (Prompt caching feature) Implicit prefix caching on AWS instances   | Up to 90% token savings; in-memory vs extended retention (up to 24h)【37†L99-L107】【47†L55-L63】 | 【37†L99-L107】【47†L55-L63】 |
| **Microsoft AutoGen**     | Explicit request cache (Disk/Redis), `cache_seed` for full determinism | Guarantees identical output; adding a cache layer; config overhead  | 【40†L90-L99】【40†L153-L161】 |
| **LangChain (Open)**      | Local InMemoryCache (dev-time); structured outputs via Pydantic    | Volatile (process-local only), but easy dev cache; uses schema models | 【37†L154-L160】【33†L146-L148】 |
| **Semantic Kernel (MS)**  | Deterministic tool planner; Pydantic state; in-memory chains       | Ensures reproducibility; complexity in modeling; plugin-centric     | 【43†L129-L138】【43†L139-L148】 |
| **Prompt Engineering Guides (Manus, etc.)** | Append-only history; explicit cache breakpoints; no in-place edits | + cache hits but requires strict serialization; manual cache flags   | 【27†L102-L110】【58†L122-L131】 |

Each approach highlights that **stable, append-only context** maximizes caching, while **structured outputs and artifacts** help offload large data. For example, NVIDIA’s fix was purely to remove billing info at prompt start【11†L148-L157】; Manus/AWS advice is to append variable data or prefetch from RAG instead. The **cache hit-rate** depends on these discipline: a single token change in prefix forces a cache miss【58†L101-L110】【47†L1-L9】. Conversely, correctness and security can be compromised if caches serve stale or private data, so monitoring and TTL management are needed【47†L23-L28】【48†L905-L914】.

## Comparison of Tradeoffs

Building determinism into agent pipelines involves balancing several dimensions:

- **Correctness & Security:** Strict determinism (exact hashing, replay logs) maximizes reproducibility, but can **leak sensitive state** if not filtered. For example, caching unredacted conversation history may expose user PII【48†L928-L936】. Masking secrets and normalizing paths (e.g. relative to project root) mitigate risk【56†L469-L478】. Security tools (sandboxed tool runners, signed manifests) add safety but complexity.

- **Cache Hit-Rate vs. Freshness:** A static prefix yields high cache hits (as Anthropic’s doc hierarchy tools→system→messages shows【56†L348-L358】), but dynamic use-cases (frequent user updates) lower reuse. Systems thus tier caches: *prompt caching* for prefix, *request-response caching* for identical queries【37†L99-L107】, and *RAG/memory* for semantically similar content. High hit-rates cut latency (sub-ms reads) and cost【37†L79-L88】, but require infrastructure (memory servers, vector DBs).

- **Storage & Write Amplification:** Persisting every turn’s full context (like Rig Relay’s JSON snapshots) wastes I/O if much of it repeats【56†L375-L383】. Industry trends favor **delta encoding** or appending minimal new info. For example, DeepAgents and Kimi frameworks log deltas between checkpoints【52†L324-L332】. Also, breaking large tool outputs into artifacts (and storing only handles in context) limits window bloat【56†L375-L383】. Tiered eviction policies (flush large results to disk first) are common【56†L375-L383】.

- **Latency vs. Complexity:** In-memory or GPU caches give fastest hit times, but need volatile memory and cluster coordination. Distributed or edge caches improve scaling at a cost of added lookup overhead. Amazon notes in-memory prompt caches expire in ~10 minutes【47†L49-L57】, whereas extended (GPU-local) can hold 24h【47†L67-L75】. More layers (agent local, global server, edge CDN) yield diminishing returns vs. engineering cost. For example, Meta/Manus suggests clients maintain their own memory and **only fetch from disk/network when needed** to reduce runtime overhead【56†L492-L502】【50†L99-L107】.

- **Developer Ergonomics:** Strict determinism can impose burdens on prompt authors (no dynamic templates), but pays off in fewer surprises. Tools like AutoGen mitigate this by simply “turning on” a cache, while others rely on developer discipline. The blueprint and guides stress rigorous conventions (append-only, fixed prompt templates) which may feel heavy initially, but lead to predictable runs and easier debugging【58†L101-L110】【52†L324-L332】.

## Rig Relay’s Approach vs. Best Practices

The provided audit rightly notes that **Rig Relay’s core engine implements many leading ideas**:

- **Prefix Stability Engine:** `ContextLayoutPlan` enforces a cache-friendly ordering (system prompt and tools first, then memory, then messages)【56†L348-L358】. This mirrors the “Golden Path” of stable prompt design【58†L101-L110】【56†L348-L358】. As a result, Rig Relay should achieve high cache locality in any prefix-caching LLM (GPU or API-side).

- **Deterministic Fingerprinting:** Using SHA256 to detect prefix drift (and annotating `prefix_stability_status`) aligns with approaches that key caches by exact hashes【38†L139-L147】. This ensures only bitwise identical contexts are considered equal, avoiding the hazards of fuzzy matching. It effectively implements the “exact reuse” mode that OpenAI and IBM describe for prompt caching【38†L139-L147】【48†L905-L914】.

- **Context Engineering Metrics:** Computing a `cacheability_ratio` and giving hints is an innovative twist. It not only caches, but educates users on how to improve cacheability. This matches advice from AWS/IBM that tracking cache hit rates and cacheable token ratios is important for ROI【37†L79-L88】【47†L109-L117】.

- **Avoiding Approximate Caches:** The audit notes Rig Relay deliberately avoids semantic memoization, favoring correctness. This conservative choice is in line with enterprise guidance: exact caching avoids the security risks of “hallucinated” cache entries and the correctness issues of approximate reuse【38†L139-L147】【48†L905-L914】.

However, current gaps suggest these **shortfalls relative to industry norms**:

- **Cache Hierarchy:** Rig Relay is single-tier (disk-only). Industry supports *multi-layer caches*: in-memory or process-local (fastest), on-disk dedup pools, and even distributed caches across sessions【37†L154-L160】【56†L492-L502】. For instance, if two sessions use the same 100KB schema, a local block pool or shared artifact store could deduplicate it, but Rig Relay re-writes it every time. Moving to a layered cache (Session vs. Project vs. Global) would greatly improve efficiency【37†L154-L160】【56†L492-L502】.

- **Write Efficiency (Delta vs. Full Snapshots):** Currently, Rig Relay writes entire JSON context reports each turn. The blueprint suggests **delta encoding** or log-structured updates to avoid full rewrites【56†L375-L383】. Without it, stable content (e.g. system prompt) is redundantly stored on every write. Industry systems (e.g. Kimi, DeepAgents) append only changes, compress logs, or use incremental checkpoints to minimize I/O【52†L324-L332】【56†L375-L383】.

- **Privacy/Path Handling:** The audit flags that raw messages and absolute paths are logged. This contravenes best practices. E.g., OpenAI’s prompt cache docs emphasize *metadata hashing* and organization-scoped caches【47†L1-L9】【48†L928-L936】, implying one should avoid exposing raw user content. Rig Relay should normalize paths (relative to project root) and redact sensitive content, as recommended by Azure/Anthropic advice on evidence management【56†L469-L478】. 

- **Evidence Integrity:** No integrity monitor means the system “assumes durability.” In high-reliability frameworks, each logged artifact (context turn, tool output) is checksummed and linked in a manifest【52†L324-L332】. Implementing such a manifest (perhaps using the existing SHA256 prefixes) would detect mid-session data loss or tampering. The audit’s suggested Evidence Manifest is essentially the same idea as logs in robust agent systems【52†L324-L332】.

## Mapping Rig Relay Features to Enhancements

| **Rig Relay Feature**        | **Current Status**                                                         | **Recommended Improvement (Priority)**                                    |
|------------------------------|---------------------------------------------------------------------------|-------------------------------------------------------------------------|
| **ContextLayoutPlan (prefix order)** | Implements stable ordering (system→memory→recent). | Maintain and refine. Align tool schema ordering with Anthropic’s cache hierarchy (tools→system→messages)【56†L348-L358】. No change needed in strategy (High maturity). |
| **SHA256 Fingerprinting**    | Uses exact hashing to detect prefix drift.                                  | Good. Consider signing or extended metadata (timestamps) only outside critical prefix, as per best practices【58†L101-L110】. |
| **Cacheability Metrics (ratio, hints)** | Generates metrics and hints per report.                                  | Expand metrics: include hit/miss logs or trends for longer sessions. Possibly integrate with external monitoring (as AWS suggests monitoring hit rates)【47†L109-L117】. |
| **No Semantic Cache**        | Only exact reuse, no approximate caching.                                   | This is a conservative, secure choice. Could offer semantic (fuzzy) caching as an option in future, but not default. |
| **Raw Messages & Paths in Logs** | Raw content (including absolute file paths) are stored in evidence. | **Critical (High)**: Implement **Path Normalization** (make paths relative to project root) and **Secret Redaction** (scrub or hash PII) before writing to the repo. This avoids leaking sensitive data【56†L469-L478】【48†L928-L936】. |
| **Single-Tier (Disk-only) Cache** | No in-memory or shared cache; every session starts cold.                     | **Medium:** Add an in-memory cache layer within the agent runtime for same-session reuse, and a **Local Block Pool** on disk to dedupe objects across sessions (if the same user/story reuses contexts). Use a multi-tier design (client → local disk → optional network/store)【37†L154-L160】【56†L492-L502】. |
| **Full JSON Snapshots (no deltas)** | Writes entire context each turn (high write-amplification).               | **Medium:** Implement **Delta-Encoding**: store only changed parts of context (e.g., append new messages and keep pointer to unchanged prefix). Compress or patch small parts only. Alternatively, log events and rebuild context on demand (event sourcing)【52†L324-L332】【56†L375-L383】. |
| **Durability Assumption (no integrity monitor)** | Assumes `.rig/relay` is persisted.                                       | **High:** Add an **Integrity Monitor**. E.g., maintain a rolling hash chain (similar to Git’s commit hashes) or an evidence manifest that verifies every context file’s existence and checksum【52†L324-L332】. Alert or rollback if corruption detected. |

These enhancements mirror industry moves (e.g. using Redis/MemoryDB caches【37†L154-L160】, artifact loggers【56†L469-L478】, and safe serialization【58†L122-L131】). Prioritization should start with **security** (path normalization, redaction) and **short-term caching improvements** (in-memory cache), then **log efficiency** (deltas) and finally **integrity tooling**. All of these align with making Rig Relay a production-grade harness.

## Architectural Diagrams and Data Flow

*(Diagrams are conceptual; in a final report they would be rendered from Mermaid code into images with explanatory captions.)*

- **Cache Hierarchy Diagram:** A multi-tier cache architecture spans from the agent runtime to the LLM service. For example, an agent might first check its in-memory cache and local disk, then route the request to a load-balancer that directs the request to a model server. The model server uses a GPU-local KV cache and possibly a shared distributed cache (e.g. Redis or NVMe) for prefix state. This layered design parallels CPU cache hierarchies: small fast caches (agent RAM, GPU memory) and larger slower stores (disk DB)【37†L154-L160】【56†L492-L502】.

- **Context/Evidence Flow:** In each turn, the agent builds a context prefix, sends it to the LLM, receives a response (and possibly calls tools), and produces an updated context report. A robust system would log every such interaction: user messages, model responses, tool outputs, and updated state. These are written to durable evidence (files or DB) and optionally emits hooks to an “evidence monitor” service. This ensures **every step is auditable and replayable**【52†L324-L332】【49†L196-L200】. (In Rig Relay’s case, such flow maps to its `ContextAssemblyReport` snapshots and planned “Evidence Manifest”.)

## Roadmap & Recommendations

1. **Short Term (0–2 months):**  
   - **Security/Privacy:** Implement **path normalization** and **secret redaction** immediately. This fixes the highest-risk issue (disallowed content in repos) with minimal complexity. Ensure any absolute paths or raw content in context are either removed or made project-relative【56†L469-L478】【48†L928-L936】.  
   - **In-Memory Cache Layer:** Add a runtime memory cache so that repeated `Agent.chat()` calls in one session can reuse the last response without disk I/O. This is straightforward and yields quick wins in latency.  
   - **Monitoring:** Begin logging cache hit/miss counts in the existing metrics to validate `cacheability_ratio` and identify frequent cache breaks.  

2. **Medium Term (3–6 months):**  
   - **Cache Hierarchy Expansion:** Develop a **Local Block Pool** on disk that deduplicates repeated blocks (tool schemas, context chunks) across sessions. This reduces footprint and write amplification【37†L154-L160】. Optionally integrate a small Redis or SQLite as an optional multi-session cache.  
   - **Delta/Append Writes:** Refactor context artifact writing to **append-only or diff-mode**. Rather than rewrite the whole JSON each turn, log incremental updates or patch the prior context. This follows the language of session event logs【52†L324-L332】.  
   - **User Configurable Cache Control:** Expose controls analogous to `cache_seed` or `prompt_cache_key`, letting users group sessions by shared prefixes. This empowers advanced routing in LLM farms (per OpenAI docs)【47†L1-L9】.

3. **Long Term (6+ months):**  
   - **Evidence Manifest & Integrity:** Design a manifest file (or a Git-like commit chain) that records checksums of each context snapshot. On session resume or on CI, verify against this manifest to detect tampering or evictions【52†L324-L332】. Possibly integrate with a verifiable ledger if needed.  
   - **Semantic/Vector Layer (optional):** As a stretch goal, consider a semantic cache tier (vector DB) to catch near-identical queries, but only once basics are solid. This yields diminishing returns and invites correctness tradeoffs, so it should remain optional.  
   - **Cloud/Edge Caching:** If Rig Relay is deployed at scale, evaluate distributed cache layers (e.g. CDN for static context, or in-memory caches in load-balanced workers) to approach a “poor-man’s Wolfram Alpha” scale. The complexity is high, so this is low priority unless scales demand it【37†L79-L88】.

Each recommendation carries risk: additional complexity, testing needed, and dev effort. But the payoff—massive token savings, predictable behavior, and data safety—is in line with production AI systems. Given the rapid evolution of agent infrastructure【3†L128-L135】【33†L85-L89】, adopting these measures will ensure Rig Relay’s design remains aligned with best practices and can support large-scale, long-running tasks reliably.

## Conclusion

In summary, **Rig Relay’s emphasis on prefix stability and exact-context caching is well-founded** and matches industry recommendations【58†L101-L110】【11†L148-L157】. These measures will pay dividends in cost and performance as LLM workloads scale. However, the *complete* picture also requires multi-tier caching and strong data hygiene. By addressing the identified gaps (privacy boundary, caching layers, write efficiency, integrity monitors), Rig Relay can fully leverage the determinism trend and become robust enough for the most demanding use cases. If implemented, its current strategy should scale effectively toward a “deterministic knowledge” agent system, turning randomness into a managed, auditable resource【49†L155-L164】【52†L324-L332】.

