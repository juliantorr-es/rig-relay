# Context Engineering and Context Caching

## Executive summary

In current LLM practice, **context** is no longer just “the prompt.” The strongest recent definitions describe it as the *set of tokens available to the model at inference time* plus the broader runtime state that determines which information enters that window: system instructions, tool schemas, retrieved documents, message history, and external memory. **Context caching** has a narrower official meaning in vendor APIs—reusing previously processed input tokens or KV state—but, in the broader systems sense used by context engineering, it also includes caching any intermediate artifact that helps reconstruct or serve the right context cheaply and correctly: browser state, retrieved documents, deltas, server-side objects, edge responses, semantic matches, and model prefix caches. citeturn32view0turn16view6turn35view0turn16view0turn19view3turn22view9

The highest-confidence conclusion from the literature and official docs is this: **optimize for exact reuse first, approximate reuse second**. Exact-prefix caches on the server side are close to a “free lunch” because they preserve model outputs while reducing prefill work; OpenAI, Anthropic, Google, and vLLM all emphasize identical-prefix reuse or cached precomputed tokens. Semantic caches can unlock larger wins when prompts recur in paraphrased form, but recent work shows they need explicit verification, threshold calibration, and stronger isolation because false hits and cross-tenant attacks are real. citeturn16view0turn16view2turn35view0turn16view7turn31view0turn31view5turn31view4

On the **client side**, the dominant pattern is a **tiered cache**: hot, ephemeral state in memory; larger structured state in IndexedDB; fetch-layer response caching via the Cache API and service workers; speculative prefetch only when the prediction quality is high; and localStorage only for tiny, non-sensitive flags because it is synchronous and exposed to XSS risk. For offline-critical apps, persistent storage should be requested explicitly rather than assumed. citeturn19view0turn19view1turn20view0turn20view4turn19view5turn22view0

On the **server side**, the dominant pattern is a **multi-layer cache hierarchy**: provider/model prefix cache, application in-memory cache, distributed cache such as Redis or Memcached, then CDN/edge caches in front of origins. Correctness depends less on any single eviction algorithm than on **versioning, invalidation, and tenant isolation**: cache keys should encode schema/version/tenant boundaries; invalidation should prefer tags, surrogate keys, or version bumps over global purges; and privacy-sensitive contexts should avoid globally shared caches, use short TTLs, ACLs, TLS, and data minimization. citeturn22view8turn22view12turn22view14turn22view15turn22view17turn22view18turn22view19turn22view2turn22view3turn22view4turn18view4turn16view2turn16view8turn16view9

## Definitions and design goals

Recent writing on context engineering is converging, but not fully standardized. urlAnthropic’s context-engineering essayturn32view0 defines context as the tokens included when sampling from an LLM and describes context engineering as curating the optimal set of tokens during inference; urlGoogle’s Gemini long-context guideturn16view6 frames the context window as the model’s short-term memory; and urlGoogle’s Gemini caching referenceturn35view0 defines context caching specifically as saving and reusing precomputed input tokens. Taking these together, the most useful systems definition is:

| Term | Practical definition for this report | Why it matters |
|---|---|---|
| **Context** | The live model-visible working set: prompt prefix, tool definitions, retrieved documents, message history, structured outputs/schema, and any external state selected into the window. citeturn32view0turn16view6 | Determines output quality, latency, and cost. |
| **Context cache** | Any store that reuses previously computed or selected context artifacts: exact-prefix token caches, KV caches, semantic/output caches, browser state, distributed object caches, and edge responses. citeturn35view0turn16view0turn16view2turn19view3turn22view9 | Determines repeated-request efficiency. |
| **Exact cache** | Reuse requires identical prefix/content identity. citeturn16view0turn16view2turn16view7 | Maximum correctness, lower hit rate. |
| **Approximate cache** | Reuse allowed for semantically similar content or delta-equivalent state. citeturn31view0turn31view5turn19view17turn19view19 | Higher hit rate, higher correctness and security burden. |

Across the sources, the design goals are consistent even when vocabulary differs. Official API docs emphasize **latency and token-cost reduction** for repeated prefixes; Redis and CDN docs emphasize **throughput, memory management, evictions, and freshness/coherence**; browser docs emphasize **quota, persistence, and eviction**; and security sources emphasize **privacy, tenant isolation, and limited retention**. In practice, almost every context-caching design is balancing six variables: **latency, throughput, consistency/freshness, memory footprint, privacy/security, and cost**. citeturn16view0turn16view2turn35view2turn22view8turn30view1turn20view4turn22view0turn9search15turn8search2

A useful mental model is to treat context as a **scarce, multi-layer working set**. Bigger context windows help, but they do not remove the need for curation: Anthropic explicitly treats context engineering as iterative curation, Google positions the context window as short-term memory, and Chroma’s “context rot” report argues that more tokens can degrade reliability rather than improve it uniformly. That means caching must be paired with **selection, compression, invalidation, and compaction**, not just “store more history.” citeturn32view0turn16view6turn33search0turn18view2

## Client-side context caching

For web and mobile clients, the best pattern is usually **three-tiered**: **RAM for hot state**, **structured persistent storage for cold state**, and **network-response caching for fetch-layer reuse**. On the web, IndexedDB is the right default for large structured context because it is transactional and stores any object supported by the structured clone algorithm; the Cache API is the right default for HTTP request/response pairs; and localStorage should be reserved for tiny convenience values because reads and writes are synchronous and can block the main thread. citeturn20view6turn20view7turn19view1

Service workers matter because they turn the client cache into an actual policy engine. MDN describes them as proxy-like components that intercept and modify requests and cache resources granularly, including support for background sync. That makes them ideal for **offline-first**, **stale-while-revalidate**, and **network-first** policies. For context-heavy apps—chat, copilots, note systems, field apps—the service worker is often the boundary that decides whether a request can be satisfied from the local context store, should be refreshed opportunistically, or must go to the network. citeturn20view0turn19view2turn20view1turn20view2turn20view3turn19view7

Browser persistence is not guaranteed unless you request it. MDN distinguishes **best-effort** storage from **persistent** storage; by default, IndexedDB and Cache API data are best-effort and may be evicted under quota pressure, while `navigator.storage.persist()` can request persistent treatment. Offline-critical context—drafts, user-authored summaries, retrieved notes for disconnected use—should assume best-effort unless persistence is granted. citeturn20view4turn20view5turn19view5

Speculative warming should be conservative. Prefetching can materially reduce navigation latency, and the Speculation Rules API gives a more expressive way to prefetch or prerender future *documents* for MPAs, while traditional prefetch remains appropriate for specific subresources. In context-engineering terms, prefetch is most effective when next actions are structurally predictable—“next page,” “open thread,” “continue agent plan”—and least effective when branching is wide. Over-prefetching wastes bandwidth, pollutes caches, and can worsen low-bandwidth performance. citeturn19view8turn19view9

Compression and serialization are useful when context objects are large or when storage/network budgets dominate. JSON is universal and debuggable but text-heavy; CBOR, Protocol Buffers, and MessagePack reduce bytes and parsing overhead in different ways; Brotli typically maximizes transfer compression for static text assets, while Zstandard often offers better real-time trade-offs at similar CPU budgets. For client caches, serialization choice is mainly a trade between **interoperability and human inspectability** versus **compactness and CPU cost**. citeturn19view13turn19view14turn19view15turn19view16turn19view11turn19view12

The LLM-specific client rule is to make the **cacheable prefix as stable and as early as possible**. OpenAI says cache hits require exact repeated prefix matches and recommends static content first, variable content last; Anthropic says caching resumes from specific prompt prefixes with automatic or explicit breakpoints; and Google recommends putting large common content at the beginning and keeping similar prefixes close in time. This implies a prompt-construction discipline: keep stable system instructions, static tools, schemas, and long-lived documents in a frozen prefix; keep volatile user state and fresh tool outputs in a suffix; version both explicitly; and compact or summarize old turns rather than letting the entire transcript mutate the prefix on every request. citeturn16view0turn16view2turn35view2turn35view3turn18view2

### Client-side technique comparison

| Technique | Strengths | Weaknesses | Best use | Evidence |
|---|---|---|---|---|
| In-memory cache | Lowest latency; zero serialization overhead | Lost on reload/app restart; easy to overgrow | Hot session context, current turn state, dedup maps | Local caching reduces network traffic and is fastest at app side. citeturn22view9turn22view10 |
| localStorage / Web Storage | Simple API; ubiquitous | Synchronous, blocking, and unsafe for sensitive data under XSS | Tiny feature flags, cache metadata, non-sensitive preferences | citeturn19view1turn22view0 |
| IndexedDB | Large structured storage; transactional; indexed; async | More operational complexity than key-value APIs | Offline documents, conversation archives, retrieval chunks, client embeddings | citeturn19view0turn20view6 |
| Cache API | Native request/response storage; good for fetch-layer reuse | Best for HTTP objects, not arbitrary app graphs | Retrieved docs, API GET responses, static assets | citeturn19view3turn20view7 |
| Service worker | Centralized request policy; offline-first; background refresh | More lifecycle complexity; harder debugging | Cache orchestration and refresh strategy | citeturn20view0turn19view2turn20view2 |
| Prefetch / Speculation Rules | Lowers perceived latency on likely next steps | Can waste bandwidth and pollute caches | Predictable navigation/flow steps | citeturn19view8turn19view9 |

### Implementation patterns and algorithms

The right eviction policy depends on workload shape. Redis documentation is explicit that approximate LRU and LFU are used to reduce overhead, while Redis’s newer LFU adds probabilistic counters with decay so it can adapt as popularity changes. CLOCK-style policies remain attractive where O(1) metadata overhead matters; PostgreSQL’s clock-sweep implementation and Solaris’s two-handed clock illustrate the “second-chance” family well. citeturn25view3turn26view0turn25view1turn25view0

```text
# LRU
get(k):
  if k not in map: return MISS
  node = map[k]
  move node to head of doubly-linked list
  return node.value

put(k, v):
  if k in map:
    map[k].value = v
    move map[k] to head
  else:
    if size == capacity:
      victim = tail.prev
      delete map[victim.key]
      remove victim
    node = new Node(k, v)
    insert_after(head, node)
    map[k] = node
```

```text
# LFU
get(k):
  if k not in values: return MISS
  f = freq[k]
  remove k from bucket[f]
  freq[k] = f + 1
  add k to bucket[f + 1]
  if bucket[min_freq] empty: min_freq += 1
  return values[k]

put(k, v):
  if capacity == 0: return
  if k in values:
    values[k] = v
    get(k)  # bumps frequency
    return
  if size == capacity:
    victim = oldest_item_in(bucket[min_freq])
    evict(victim)
  values[k] = v
  freq[k] = 1
  add k to bucket[1]
  min_freq = 1
```

```text
# CLOCK / second chance
evict():
  loop:
    page = ring[hand]
    if page.ref_bit == 0:
      victim = page
      hand = (hand + 1) mod N
      return victim
    else:
      page.ref_bit = 0
      hand = (hand + 1) mod N
```

For **delta updates**, the most robust general approach is versioned patches. JSON Patch represents an ordered sequence of operations; JSON Merge Patch is simpler but coarser; HTTP delta encoding is the transport-level ancestor for “send only changes.” In context systems, deltas make sense when most of the context is stable and only a small suffix or field subset changes. The two failure cases are patch-chain drift and hidden coupling to old schema versions, so production deltas should be anchored to a **base version hash**. citeturn19view17turn19view19turn19view18

```text
# Delta encode against last acknowledged version
encode_delta(base_version, old_obj, new_obj):
  if hash(old_obj) != base_version.hash:
    return FULL_SNAPSHOT(new_obj, version=hash(new_obj))
  patch = diff_json_patch(old_obj, new_obj)
  if size(patch) >= 0.7 * size(new_obj):
    return FULL_SNAPSHOT(new_obj, version=hash(new_obj))
  return PATCH(base=base_version.hash, ops=patch, version=hash(new_obj))
```

For **context stitching**, the key is deterministic assembly order. Stable items must stay together so exact-prefix reuse survives across turns. Variable elements should be appended in deterministic slots with explicit versioning and budget rules. This is the most important practical bridge between client and server context caching. citeturn32view0turn16view0turn16view2turn35view3

```text
# Context stitching for an LLM request
build_context(user_turn, session_state):
  prefix = [
    system_prompt(version="sys:v12"),
    tool_schemas(version="tools:v7"),
    policy_docs(version="policy:2026-05-01"),
    long_lived_memory(session_state.memory_version)
  ]  # stable, cacheable prefix

  recent = compact_recent_history(session_state.history, budget=K)
  retrieved = retrieve_relevant_docs(user_turn, top_k=M)
  suffix = [
    recent,
    retrieved,
    tool_outputs_since_last_turn(session_state),
    user_turn
  ]  # volatile suffix

  return trim_to_budget(prefix + suffix, reserve_for_output=R)
```

## Server-side context caching

Server-side caching is where context engineering intersects directly with inference systems. Official docs from OpenAI, Anthropic, Google, and vLLM all converge on the same core optimization: **reuse previously processed prefixes**. OpenAI routes requests to servers that recently processed the same prompt and requires exact repeated prefix matches; Anthropic caches prefixes up to a breakpoint with automatic or explicit control; Google offers both implicit and explicit context caching; and vLLM hashes KV-cache blocks by token content and prefix to enable exact prefix reuse with LRU-based eviction. These are all forms of **prefill avoidance**: reduce time-to-first-token by not recomputing shared context. citeturn16view0turn16view2turn35view2turn16view7

The main provider differences are **policy surface area and retention semantics**. OpenAI’s prompt caching is automatic, available for prompts of 1024+ tokens, exposes `cached_tokens`, and states that caches are not shared across organizations, with extended prompt caching retained at most 24 hours. Anthropic supports automatic and explicit breakpoints, defaults to a 5-minute cache lifetime, offers a 1-hour option at higher cost, exposes cache read/write token counters, and states the feature is eligible for Zero Data Retention arrangements. Google distinguishes implicit caching—automatic on newer Gemini models—from explicit cached-content objects with configurable TTL, defaulting to one hour. citeturn18view3turn18view4turn16view2turn18view5turn35view2turn35view1

Below the model tier, classic server caches still matter. Redis positions client-side caching and server-side in-memory caching as ways to reduce network traffic and database load; Memcached presents itself as a high-performance distributed memory object cache. In other words, even if provider-side token caching exists, application-side caches remain necessary for retrieval results, normalized tool outputs, policy objects, and stitched context fragments that would otherwise be recomputed before the prompt is even assembled. citeturn22view9turn22view10turn22view7

Sharding and replication are non-negotiable once concurrency scales. Redis Cluster partitions keys across 16,384 hash slots; shards replicate among themselves; replicas can take over on failover; and Redis Enterprise describes multi-shard databases and geo-distributed replicas. Memcached’s proxy examples show basic consistent hashing and optional replication/failover policies. The design implication is straightforward: if the cache key is part of the consistency contract, then **tenant ID, version, and scope must be embedded before hashing/sharding**. Otherwise, you get hot-spotting, inconsistent invalidation, or cross-tenant ambiguity. citeturn23search14turn23search6turn23search3turn23search20turn22view6turn26view5

Invalidation is the hard problem, as usual. Redis’s consistency guidance describes invalidation, write-through, and write-behind as the three classic answers. CDN vendors independently converge on more precise invalidation primitives: Cloudflare supports purge by URL and cache tags; Fastly recommends surrogate keys over frequent purge-all; Google Cloud CDN supports cache tags and path/host matchers; and CloudFront shows how stale-while-revalidate and stale-if-error can trade freshness for resilience. The systems lesson is that **coherence should be driven by explicit, semantic invalidation units**—tenant/version/tag/object class—not by time alone. TTLs are necessary but not sufficient. citeturn22view12turn22view15turn22view16turn22view17turn22view18turn22view19turn22view14

Persistence and restart behavior matter more than many “cache-only” architectures admit. Redis supports snapshotting (RDB), append-only persistence (AOF), and hybrid persistence; Memcached supports warm restart and can recover cache state across clean restarts in some cases. For long-running agent systems, prompt compaction summaries, retrieval normalizations, or semantic-cache indexes can be expensive enough that “cold restart = empty cache” is unacceptable. Snapshotting or warm restart is therefore an optimization for **operational continuity**, not just durability. citeturn22view11turn26view4

### Server-side technique comparison

| Server-side layer | Best property | Main drawback | Best fit | Evidence |
|---|---|---|---|---|
| Provider exact-prefix / KV cache | Largest TTFT savings without changing outputs | Prefix identity must remain stable; memory pressure/evictions | Repeated system prompts, tool schemas, long documents, agent loops | citeturn16view0turn16view2turn35view2turn16view7 |
| In-process application cache | Lowest app-side latency | Weak sharing across instances | Small fleets, hot normalized objects | General app-local caching rationale plus Redis client-side caching. citeturn22view9turn22view10 |
| Distributed cache (Redis / Memcached) | Shared reuse across workers; explicit TTL/eviction control | Consistency/invalidation complexity | High concurrency, reused retrieval objects, tool outputs | citeturn22view7turn22view8turn22view12 |
| CDN / edge cache | Massive read fan-out reduction | Freshness and coherence are harder; regional behavior can diverge | Static prompts/assets, retrieval APIs, document blobs | citeturn22view14turn22view15turn22view17turn27search11 |

### Multi-tenant isolation

Recent security work makes multi-tenant boundaries a first-class cache design issue, not an afterthought. An ICML 2025 audit found prompt caching and global cache sharing across users in several language-model APIs; the NDSS 2025 PROMPTPEEK paper showed prompt leakage risks from KV-cache sharing in multi-tenant LLM serving; and new work on semantic-cache key collisions shows that approximate matching can become an integrity attack surface. Official controls help—OpenAI’s org-scoped cache statement, Anthropic’s ZDR eligibility, Redis ACL/RBAC/TLS—but they do not remove the need for **tenant-scoped keys, isolated namespaces/endpoints, and threat modeling of timing and collision channels**. citeturn16view8turn16view9turn31view4turn18view4turn16view2turn22view2turn22view3turn22view4turn22view5

## Hybrid synchronization and consistency

The most robust production pattern is **hybrid caching with explicit synchronization semantics**. The client should own hot ephemeral context and possibly some offline memory, while the server owns authoritative shared state, distributed invalidations, and heavy caches. Redis’s server-assisted client-side caching is a good example of this boundary: the server tracks which keys a client may have cached and sends `INVALIDATE` messages when another client changes them. This pattern generalizes well to LLM systems: the browser/mobil app caches local stitched prefixes or retrieved objects, while the server remains responsible for invalidating stale versions of policy docs, team memories, and tool schemas. citeturn26view3turn22view9

**Optimistic updates** are best when the user value of local responsiveness is higher than the cost of occasional rollback. That usually includes drafts, notes, chat edits, scratchpads, and user-facing agent plans. For **conflict-heavy or offline-collaborative** systems, local-first and CRDT-based approaches are stronger: Automerge describes local-first software as prioritizing the user’s local copy as primary, enabling offline work and real-time collaboration, and CRDTs as the merge mechanism for independently edited state. The trade-off is important: you gain availability and offline performance, but you accept eventual rather than immediate centralized consistency. citeturn6search4turn6search1turn34search0turn34search5

The right consistency choice depends on the *semantic meaning* of the context fragment. **Strong or near-strong consistency** is warranted for anything that can change permissions, money, legal obligations, or system truth—authentication context, safety policy versions, billing status, inventory, or secrets. **Eventual consistency** is often acceptable for user drafts, summarized history, retrieved documents that are not transactional records, cached embeddings, or plan state that can be regenerated. The mistake is to apply one mode to all context. Context engineering works better when the context is decomposed into **coherence classes** with different freshness contracts. citeturn22view12turn22view14turn22view19turn6search4turn6search5

The architecture below captures the pattern that appears most often across the official docs and recent systems work: stable prefixes cached high in the stack, mutable suffixes versioned and invalidated quickly, and tenant/version boundaries carried through every layer. citeturn16view0turn16view2turn35view2turn22view12turn26view3

```mermaid
flowchart LR
    U[User] --> C[Client app]
    C --> M[Hot in-memory cache]
    C --> I[IndexedDB / persistent local store]
    C --> SW[Service worker / fetch policy]
    SW --> E[Edge / CDN cache]
    E --> A[API tier]
    A --> D[Distributed cache]
    A --> R[Retrieval + object store]
    A --> L[LLM gateway]
    L --> P[Provider prefix / KV cache]
    D --> X[Invalidation bus]
    X --> C
    X --> D
    X --> E
```

And the lifecycle below shows the practical “golden path” for correctness-sensitive caches: canonicalize, check exact reuse first, verify approximate reuse if used at all, then write with version and invalidation metadata. citeturn16view7turn31view0turn22view14turn22view15turn22view17

```mermaid
flowchart TD
    A[Request arrives] --> B[Canonicalize key: tenant + version + prefix hash]
    B --> C{Exact cache hit?}
    C -- Yes --> D[Serve cached context]
    C -- No --> E{Semantic / delta candidate?}
    E -- Yes --> F[Verify threshold / base version]
    F -- Pass --> G[Serve verified approximate hit]
    F -- Fail --> H[Recompute / refetch]
    E -- No --> H
    H --> I[Write result with TTL, tags, version]
    I --> J[Emit metrics: hit, miss, size, latency]
    J --> K{Source state changed?}
    K -- Yes --> L[Invalidate by tag / version bump / surrogate key]
    K -- No --> M[Retain until TTL or eviction]
```

## Metrics, benchmarks, and decision matrix

The minimum viable metric set should include **hit rate**, **byte hit rate / cached token count**, **p50/p95/p99 latency**, **TTFT**, **throughput**, **eviction rate**, **stale-read rate**, **invalidation lag**, **memory footprint**, and **cold-start warm-up time**. OpenAI exposes `cached_tokens`; Anthropic exposes cache read/write token counters; Gemini exposes hit counts in `usage_metadata`; Redis INFO exposes hits, misses, evicted keys, and time above maxmemory; Memcached recommends monitoring slab evictions and hit rate; browser performance APIs expose navigation/resource timing and `Server-Timing`; and Lighthouse audits TTL and transfer waste for cacheable assets. citeturn18view0turn18view5turn18view6turn30view1turn30view0turn30view3turn30view4turn30view2turn30view5turn30view6

| Metric | Why it matters | How to measure |
|---|---|---|
| Prefix hit rate / cached tokens | Direct measure of exact-prefix reuse | OpenAI `cached_tokens`, Anthropic cache counters, Gemini `usage_metadata` citeturn18view0turn18view5turn18view6 |
| TTFT | Best latency signal for prompt/KV caching | Provider traces; compare cache-hit and cache-miss TTFT citeturn18view1turn31view6 |
| Resource fetch latency | Client-side response-cache effectiveness | Resource Timing / PerformanceResourceTiming citeturn30view4turn27search6 |
| End-user page/app latency | User-visible outcome | PerformanceNavigationTiming; Lighthouse audits citeturn30view3turn30view6turn30view5 |
| Cache pressure | Whether memory policy is hurting reuse | Redis `evicted_keys`, Memcached slab evictions citeturn30view1turn30view0 |
| Freshness / stale-read rate | Whether invalidation policy is good enough | Tag/version mismatch counts; server-side validation logs citeturn22view14turn22view19 |
| Throughput | Whether caching actually increases system capacity | Redis INFO ops/sec; load tests with memtier_benchmark citeturn28search0turn30view7turn30view9 |

For **benchmarking**, use both **microbenchmarks** and **end-to-end traces**. Microbenchmarks tell you about pure cache mechanics—Redis suggests `memtier_benchmark`, and Redis benchmark docs also point to YCSB and rpc-perf—but context engineering needs trace realism: repeated prefixes, paraphrase clusters, invalidation spikes, tenant boundaries, and cold-start arrivals. For client-side work, capture browser timings and Server-Timing headers so CDN/API/provider cache layers can be decomposed cleanly. citeturn30view7turn30view8turn30view9turn30view2turn30view4

A simple cost model that works well in practice is:

**Expected latency**  
`= miss_rate * full_compute + exact_hit_rate * exact_read + semantic_hit_rate * verification_cost + invalidation_overhead + decompression_overhead`

**Expected cost**  
`= miss_rate * full_token_or_origin_cost + exact_hit_rate * cached_read_cost + storage_cost + egress + write_amplification`

This is a synthesis rather than a vendor formula, but it maps directly to the cost/latency primitives exposed in provider docs and cache instrumentation. citeturn16view0turn16view2turn35view2turn18view5turn30view1

### Decision matrix by use case

| Use case | Primary constraint | Client recommendation | Server recommendation | Consistency recommendation |
|---|---|---|---|---|
| **Mobile / intermittent connectivity** | Offline availability and small bandwidth budget | In-memory + IndexedDB/local DB, service worker/background sync, persistent storage request, deltas over snapshots | Edge cache for blobs/docs; distributed cache for normalized retrievals | Eventual for drafts/history, strong for auth/policy/material truth citeturn20view4turn19view5turn19view7turn19view8turn26view3 |
| **Browser web app** | Perceived latency and reload persistence | Cache API + service worker; prefetch only for high-confidence next steps; localStorage only for tiny flags | CDN/edge plus app cache; tag-based invalidation | Mostly stale-while-revalidate for read-heavy assets; versioned invalidation for shared docs citeturn20view2turn20view3turn19view1turn22view14turn22view15turn22view19 |
| **Low-bandwidth AI assistant** | Transfer size and repeat prompts | Binary serialization for local artifacts; compression; stable prefix assembly | Explicit provider cache + distributed cache for retrieval chunks | Prefer exact prefix reuse; use deltas only with strict base-version checks citeturn19view14turn19view15turn19view16turn19view11turn19view12turn16view0turn16view2turn35view2 |
| **High-concurrency enterprise** | Throughput, hot-spotting, warm-up | Keep client state thin; rely on invalidation-aware local caches | Multi-layer hierarchy: provider prefix cache, Redis/Memcached, CDN; shard by scoped key | Exact or tag/versioned invalidation; avoid global purges | citeturn22view9turn23search14turn23search6turn22view14turn22view17 |
| **Privacy-sensitive / regulated** | Leakage risk and retention | Do not put raw sensitive context in localStorage; encrypt carefully if cached locally | Per-tenant namespaces/endpoints, ACL/RBAC, TLS, short TTLs, minimal retention; avoid global semantic caches | Strong isolation > hit rate; prefer miss over false or cross-tenant hit citeturn22view0turn19view10turn21view3turn22view2turn22view3turn22view4turn16view8turn16view9turn31view4turn9search15turn8search2 |

## Security, operations, and open research problems

Security and privacy are now central to context caching, not peripheral. On the client side, OWASP explicitly warns against storing sensitive information or session identifiers in localStorage because a single XSS can read it; browser-stored data should be treated as attacker-accessible unless protected by stronger controls. On the server side, Redis provides ACLs, RBAC, and TLS, but TLS reduces throughput somewhat, so the performance/security trade-off is real rather than theoretical. The Web Crypto API is available for encryption, but MDN repeatedly warns that key management and correct use are specialist tasks. The correct practical advice is therefore: **cache less sensitive data, encrypt selectively, rotate aggressively, and assume local/browser state is inspectable by the origin’s scripts**. citeturn22view0turn22view1turn22view2turn22view3turn22view4turn19view10turn21view0turn21view3

For compliance, the relevant GDPR principles are straightforward even if implementation is not: personal data should be limited to what is necessary, kept only as long as necessary, and protected appropriately. In cache design that translates into **data minimization, explicit TTLs, short retention for sensitive context, review/erasure procedures, and careful separation of cached telemetry from cached content**. A privacy-preserving cache design is typically a *smaller* cache design. citeturn9search15turn8search2turn8search7

Operationally, three practices dominate the sources and are easy to defend analytically. First, **cache warming**: send canonical stable prefixes, precompute cached-content objects, or prefetch known blobs immediately after deploy/startup, especially when large context docs or tool schemas are reused. Second, **cold-start mitigation**: use stale-while-revalidate or stale-if-error at the edge, retain warm state where supported, and compact old conversation state so working sets stay small enough to rewarm quickly. Third, **observability by layer**: expose Server-Timing headers from CDN, API, retrieval, and model tiers so a “slow request” can be decomposed into miss-at-edge, miss-in-Redis, miss-in-prefix-cache, or provider cold-prefill. citeturn22view14turn26view4turn30view2turn18view2turn30view7

The open research frontier is shifting quickly, and several of the most relevant papers are still preprints. The big unresolved questions are: how to make **semantic caches predictable** without giving up most of their hit-rate win; how to defend **multi-tenant prompt/KV/semantic caches** from timing and collision attacks; how to do **workflow-aware, beyond-prefix reuse** for long-running agents whose shared context is non-contiguous; and how to standardize **benchmarks that combine correctness, cost, privacy, and concurrency**, rather than optimizing only hit rate or TTFT in isolation. citeturn31view0turn31view4turn16view8turn16view9turn31view1turn31view6turn31view8turn33search0

Representative primary and recent sources worth prioritizing are: urlAnthropic’s context-engineering essayturn32view0, urlOpenAI’s prompt-caching guideturn16view0, urlOpenAI’s Prompt Caching 201 cookbookturn16view1, urlGoogle’s Gemini context-caching guideturn35view2, urlvLLM’s automatic prefix-caching design noteturn16view7, urlthe ICML 2025 auditing paper on prompt cachingturn16view8, urlthe NDSS 2025 PROMPTPEEK paper on KV-cache leakageturn16view9, urlvCache on verified semantic prompt cachingturn31view0, urlKVFlow on workflow-aware prefix cachingturn31view1, and urlthe 2026 semantic-caching management paper for LLM embeddingsturn31view5. Several of the 2025–2026 systems papers are preprints rather than archival conference publications, so their claims are promising but not equally mature. citeturn31view0turn31view1turn31view5turn31view6

The most defensible implementation advice, taken as a whole, is therefore:

1. **Stabilize and canonicalize the exact prefix first.**  
2. **Use tiered caches, not one cache.**  
3. **Encode tenant, version, and schema into every cache key.**  
4. **Prefer tag/version invalidation over broad TTL-only freshness.**  
5. **Use semantic caches only with verification and isolation.**  
6. **Measure TTFT, stale-read rate, and invalidation lag—not just hit rate.**  
7. **Treat privacy-sensitive context as something to minimize, not maximize.** citeturn16view0turn16view2turn35view2turn22view12turn22view14turn22view19turn31view0turn31view4turn16view8turn16view9

## Open questions and limitations

The term **context engineering** is still emerging and is used more consistently in recent industry essays than in standard academic taxonomies, so some of the taxonomy in this report is a synthesis rather than a settled field definition. Likewise, several of the most directly relevant papers on semantic caching, workflow-aware KV eviction, and long-horizon agent caching are 2025–2026 preprints, which means the field is moving faster than archival consensus. Finally, official docs are strongest on *what features exist* and weaker on *comparative benchmarks across providers*, so cross-provider performance conclusions should be treated as directional unless reproduced inside one controlled workload harness. citeturn32view0turn16view0turn16view2turn35view2turn31view0turn31view1turn31view2turn31view6